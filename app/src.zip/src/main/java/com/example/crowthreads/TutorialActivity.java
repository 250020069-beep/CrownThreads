package com.example.crowthreads; // Verifica que coincida exactamente con el paquete de tu proyecto

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class TutorialActivity extends AppCompatActivity {

    private int currentStep = 0;

    private final String[] stepIcons = {
            "👑",
            "👗",
            "💇‍♀️",
            "📸"
    };

    private final String[] stepColors = {
            "#FCEBF1", // Rosa pastel
            "#E8DFF5", // Lavanda pastel
            "#FCE1E4", // Melocotón pastel
            "#FFF0F5"  // Crema rosado
    };

    private final String[] stepTitles = {
            "1. Bienvenida al Palacio",
            "2. Categorías de Vestuario",
            "3. Peinados y Accesorios",
            "4. Guarda tus Creaciones"
    };

    private final String[] stepDescriptions = {
            "En Crown & Threads tienes total libertad creativa. No hay niveles ni límites de tiempo: diseña atuendos a tu propio ritmo.",
            "Usa el menú lateral izquierdo del vestidor para elegir entre vestidos, zapatillas, sombreros y aretes.",
            "Toca las opciones de la barra inferior para probar distintos peinados y combinaciones sobre tu modelo al instante.",
            "Cuando termines tu diseño favorito, guárdalo en la Galería o ajusta tus preferencias en los Ajustes del Palacio."
    };

    private TextView tvStepIndicator, tvIcon, tvTitle, tvDescription;
    private ProgressBar progressBar;
    private MaterialButton btnPrev, btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        // Vincular vistas
        tvStepIndicator = findViewById(R.id.tv_tutorial_step_indicator);
        tvIcon = findViewById(R.id.tv_tutorial_icon);
        tvTitle = findViewById(R.id.tv_tutorial_title);
        tvDescription = findViewById(R.id.tv_tutorial_description);
        progressBar = findViewById(R.id.progress_tutorial);

        MaterialButton btnSkip = findViewById(R.id.btn_skip_tutorial);
        btnPrev = findViewById(R.id.btn_prev_step);
        btnNext = findViewById(R.id.btn_next_step);

        // Cargar primer paso
        updateTutorialUI();

        // Botón Saltar
        if (btnSkip != null) {
            btnSkip.setOnClickListener(v -> finish());
        }

        // Botón Anterior
        if (btnPrev != null) {
            btnPrev.setOnClickListener(v -> {
                if (currentStep > 0) {
                    currentStep--;
                    updateTutorialUI();
                }
            });
        }

        // Botón Siguiente / Finalizar
        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                if (currentStep < stepTitles.length - 1) {
                    currentStep++;
                    updateTutorialUI();
                } else {
                    finish(); // Cierra el tutorial al terminar el último paso
                }
            });
        }
    }

    private void updateTutorialUI() {
        int totalSteps = stepTitles.length;
        tvStepIndicator.setText("Paso " + (currentStep + 1) + " de " + totalSteps);
        progressBar.setProgress(currentStep + 1);

        tvIcon.setText(stepIcons[currentStep]);
        tvIcon.setBackgroundColor(Color.parseColor(stepColors[currentStep]));
        tvTitle.setText(stepTitles[currentStep]);
        tvDescription.setText(stepDescriptions[currentStep]);

        // Habilitar/deshabilitar botón Anterior
        btnPrev.setEnabled(currentStep > 0);
        btnPrev.setAlpha(currentStep > 0 ? 1.0f : 0.5f);

        // Cambiar texto en el último paso
        if (currentStep == totalSteps - 1) {
            btnNext.setText("¡COMENZAR!");
        } else {
            btnNext.setText("SIGUIENTE");
        }
    }
}