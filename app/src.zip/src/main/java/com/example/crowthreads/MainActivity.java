package com.example.crowthreads;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Abre directamente la pantalla de Ajustes para que la pruebes en tu emulador/celular
        startActivity(new Intent(this, SettingsActivity.class));
        finish();
    }
}